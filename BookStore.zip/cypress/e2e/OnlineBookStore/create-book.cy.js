describe('Add New Book Page', () => {
    beforeEach(() => {
        cy.visit('http://localhost/online-book-store-main/login.php');
        const email = 'eliasfsdev@gmail.com';
        const password = '123';
        cy.get('input[name="email"]').type(email);
        cy.get('input[name="password"]').type(password);
        cy.get('button[type="submit"]').click();
        cy.url().should('include', '/admin.php');
        cy.visit('http://localhost/online-book-store-main/add-book.php');
    });

    it('should add a new book successfully with correct data', () => {
        const bookTitle = 'Test Book Title';
        const bookDescription = 'This is a test book description.';
        const bookAuthor = '1';
        const bookCategory = '1';
        const bookCover = 'sample.jpg';
        const file = 'sample.pdf';

        cy.get('input[name="book_title"]').type(bookTitle);
        cy.get('input[name="book_description"]').type(bookDescription);
        cy.get('select[name="book_author"]').select(bookAuthor);
        cy.get('select[name="book_category"]').select(bookCategory);
        cy.get('input[name="book_cover"]').attachFile(bookCover);
        cy.get('input[name="file"]').attachFile(file);
        cy.get('button[type="submit"]').click();

        cy.contains('The book successfully created!').should('be.visible');
    });

    it('should display an error message with missing data', () => {
        const bookCover = 'sample.jpg';
        const file = 'sample.pdf';

        cy.get('input[name="book_description"]').type('This is a test book description.');
        cy.get('select[name="book_author"]').select('1');
        cy.get('select[name="book_category"]').select('1');
        cy.get('input[name="book_cover"]').attachFile(bookCover);
        cy.get('input[name="file"]').attachFile(file);
        cy.get('button[type="submit"]').click();
        cy.contains('The Book title is required').should('be.visible');
    });
});
