describe('Login Page', () => {
    beforeEach(() => {
        cy.visit('http://localhost/online-book-store-main/login.php');
    });

    it('should login successfully with correct credentials', () => {
        const email = 'eliasfsdev@gmail.com';
        const password = '123';
        cy.get('input[name="email"]').type(email);
        cy.get('input[name="password"]').type(password);
        cy.get('button[type="submit"]').click();
        cy.url().should('include', '/admin.php');
    });

    it('should display an error message with incorrect credentials', () => {
        const email = 'wronguser@example.com';
        const password = 'wrongpassword';
        cy.get('input[name="email"]').type(email);
        cy.get('input[name="password"]').type(password);
        cy.get('button[type="submit"]').click();
        cy.contains('Incorrect User name or password').should('be.visible');
    });
});
